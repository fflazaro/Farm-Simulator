

public class dog extends animal {
	public dog(String name) {
		super(name);
		
	}
	
	@Override
	// Method for animal to Speak
		public void speak() {
			int amountOfTimesCanSpeak = (hungerLevel + 2);
			if (asleep == false) {
				amountOfTimesAnimalSpoken++;
				if (amountOfTimesAnimalSpoken != amountOfTimesCanSpeak) {
					System.out.println("Woof woof");
				}
			} else if (asleep == true) {
				System.out.println("Snore!");
			}

		}

	

	@Override
	public void printHungerLevel() {
		// Print hunger level
				calculateHungerLevel();
				System.out.println(name + " the dog is " + printHungerLevel);
		
	}
	
	
		
}
