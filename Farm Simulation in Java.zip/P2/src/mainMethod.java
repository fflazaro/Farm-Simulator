import java.util.ArrayList;
import java.util.Collections;


public class mainMethod {
	

	public static void main(String[] args) {
		ArrayList<animal> farm = new ArrayList<>();
		//Add instances of the animals
		cow cow1 = new cow("Belle");
		dog dog1 = new dog("Dawn");
		cat cat1 = new cat("Philip");
		chicken chicken1 = new chicken("Polly");
		sheep sheep1 = new sheep("Daniel");
		cow cow2 = new cow ("Franz");
		dog dog2 = new dog("Daisy");
		cat cat2 = new cat("Jane");
		chicken chicken2 = new chicken("Harley");
		sheep sheep2 = new sheep("Billy");
		
		//Add animals to the array list 
		farm.add(cow1);
		farm.add(cow2);
		farm.add(dog1);
		farm.add(dog2);
		farm.add(cat1);
		farm.add(cat2);
		farm.add(chicken1);
		farm.add(chicken2);
		farm.add(sheep1);
		farm.add(sheep2);
		
		//Sort array 
		Collections.sort(farm);
		
		int feedingLevel = 0;
        boolean allFull = false;

        while(!allFull) {
        	feedingLevel++;
        	System.out.println("Feeding " + feedingLevel);
        	for(animal animal: farm) {
        		animal.tick();
        		animal.feedAnimal();
        		animal.speak();
        		animal.printHungerLevel();
        	}
        	System.out.println();
        	allFull = true;
        	for(animal animal: farm) {
        		if(animal.getHungerLevel()>0) {
        			allFull = false;
        		}	
        	}
        }
	}
}
