//Name: Franchesca Lazaro
//Section: 
//Program Name: Programming Assignment #2 

//Description: The assignment is to make a farm simulation in which the animals on the farm make noises and they can be fed food. 
//Once you feed them enough food or make them all full, the simulation stops running. 
//The farm animals will have different hunger levels that increase by one over time, but if you feed them, they have a chance of falling asleep. 

//Imports
import java.util.Random;

public abstract class animal implements Comparable<animal> {
	int hungerUnits;
	int hungerLevel;
	boolean asleep = false;
	String name;
	String printHungerLevel;
	int secondsPassed = 0;
	Random rand = new Random();
	int amountOfTimesAnimalSpoken = 0;

	public animal(String name) {
		super();
		this.name = name;
		hungerUnits = rand.nextInt(25);
		asleep = false; 

	}

	//Returns hunger level 
	public int getHungerLevel() {
		return hungerUnits / 5;
	}


	// Method to Feed Animal and Calculate Chance of Animal Falling Asleep
	public void feedAnimal() {
		// If the animal is asleep, you can't feed it. However, if it isn't, you can.
		if (asleep == true) {
			System.out.println("The animal is asleep! You cannot feed it.");
		} else if (asleep == false) {
			//If the hunger units is less than 0, make it equal to 0. Else, subtract 5 units. 
			if (hungerUnits < 0) {
				hungerUnits = 0;
			} else {
				hungerUnits -= 5;
			}
		}
		// 10 percent chance that the animal will fall asleep each time you feed it.
		sleep();
	}

	public void tick() {
		//Simulation for time 
		//Check if hunger units is more than 24 and if not, add to it. If the hunger level changes, wake it up. 
		if (hungerUnits >= 24) {
			hungerUnits = 24;
		} else {
			hungerUnits++;
		}
		if ((hungerUnits % 5 == 0)) {
			asleep = false;
		}

	}

	// 10 percent chance that the animal will fall asleep each time you feed it.
	public void sleep() {
		int randNum = rand.nextInt(10);
		if (randNum == 1) {
			asleep = true;
		}
	}

	public void calculateHungerLevel() {
		if (hungerUnits <= 4) {
			printHungerLevel = "full";
			hungerLevel = hungerUnits / 5; 
		} else if (hungerUnits >= 5 && hungerUnits <= 9) {
			printHungerLevel = "peckish";
			hungerLevel = hungerUnits / 5;
		} else if (hungerUnits >= 10 && hungerUnits <= 14) {
			printHungerLevel = "hungry";
			hungerLevel = hungerUnits / 5;
		} else if (hungerUnits >= 15 && hungerUnits <= 19) {
			printHungerLevel = "very hungry";
			hungerLevel = hungerUnits / 5;
		} else {
			printHungerLevel = "starving";
			hungerLevel = hungerUnits / 5;
		}
	}
	
	//
	@Override
	public int compareTo(animal animal) {
		return animal.getHungerLevel() - this.getHungerLevel();
	}

	//Specify the animal and print the hunger level 
	public abstract void printHungerLevel();

	// Method for animal to Speak
	public abstract void speak();
}
