public class cow extends animal {
	public cow(String name) {
		super(name);
		 
	}
	
	@Override 
	// Method for animal to Speak
		public void speak() {
			int amountOfTimesCanSpeak = (hungerLevel + 1) * 2;
			if (asleep == false) {
				amountOfTimesAnimalSpoken++;
				if (amountOfTimesAnimalSpoken != amountOfTimesCanSpeak) {
					System.out.println("Moo moo");
				}
			} else if (asleep == true) {
				System.out.println("Snore!");
			}

		}


	@Override
	public void printHungerLevel() {
		// Print hunger level
				calculateHungerLevel();
				System.out.println(name + " the cow is " + printHungerLevel);
		
	}

	
}
