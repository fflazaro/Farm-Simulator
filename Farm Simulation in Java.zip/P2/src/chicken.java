


public class chicken extends animal {
	public chicken(String name) {
		super(name);
		 
	}
	
	@Override 
	// Method for animal to Speak
		public void speak() {
			int amountOfTimesCanSpeak = (hungerLevel * 3);
			if (asleep == false) {
				amountOfTimesAnimalSpoken++;
				if (amountOfTimesAnimalSpoken != amountOfTimesCanSpeak) {
					System.out.println("Cluck cluck");
				}
			} else if (asleep == true) {
				System.out.println("Snore!");
			}

		}


	@Override
	public void printHungerLevel() {
		// Print hunger level
				calculateHungerLevel();
				System.out.println(name + " the chicken is " + printHungerLevel);
		
	}
	
	
}
